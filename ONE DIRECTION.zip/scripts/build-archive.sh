#!/usr/bin/env bash
# build-archive.sh — produce a source-only handoff archive
#
# Excludes: build output, node_modules, caches, logs, .env files, git-freebuff
# metadata. The ONLY env file that may be included is the validated root
# .env.example, and only when it is placeholder-safe.
#
# NEVER appends to a compressed archive. NEVER writes into the tree being
# archived. Uses a staging directory + atomic mv at the end.
set -euo pipefail

ARCHIVE_NAME="${ARCHIVE_NAME:-one-direction-source.tar.gz}"
ARCHIVE_DIR="${ARCHIVE_DIR:-.}"
STAGING_ROOT="${STAGING_ROOT:-.}"

mkdir -p "$ARCHIVE_DIR"
OUT="$ARCHIVE_DIR/$ARCHIVE_NAME"

# Remove any stale file so a failed run can't be mistaken for a good one.
rm -f "$OUT"

chdir="$(pwd)"

# --- validate root .env.example first ---
validate_env_example() {
  if [ ! -f .env.example ]; then
    return 0
  fi

  # The strict rule: every line must be blank, comment, or
  # KEY=VALUE. No bare secret-looking strings, no multi-line junk.
  while IFS= read -r line || [ -n "$line" ]; do
    stripped="${line#"${line%%[![:space:]]*}"}"
    stripped="${stripped%"${stripped##*[![:space:]]}"}"

    # blank
    [ -z "$stripped" ] && continue
    # comment
    [[ "$stripped" == \#* ]] && continue

    # must be KEY=...
    if ! [[ "$stripped" =~ ^[A-Za-z_][A-Za-z0-9_]*= ]]; then
      echo "build-archive: .env.example contains a suspicious non-assignment line:" >&2
      echo "  $stripped" >&2
      return 1
    fi

    value="${stripped#*=}"
    value="${value#"${value%%[![:space:]]*}"}"
    value="${value%"${value##*[![:space:]]}"}"

    # strip surrounding quotes once
    case "$value" in
      \"*) value="${value#\"}"; value="${value%\"}" ;;
      "'"*) value="${value#\'}"; value="${value%\'}" ;;
    esac

    # Acceptable placeholder / metadata values
    if [[ "$value" =~ ^(xxx|placeholder|your-|YOUR-|YOUR_|REPLACE_ME|REPLACE\.ME|<[^>]+>|\$\{[A-Za-z_][A-Za-z0-9_]*\}|[_\$.]+|https?://|localhost|[0-9]+|true|false|yes|no|null|undefined|none|\"\"|'') ]]; then
      continue
    fi

    echo "build-archive: root .env.example contains a non-placeholder value:" >&2
    echo "  $stripped" >&2
    return 1
  done < .env.example

  return 0
}

if ! validate_env_example; then
  exit 1
fi

# --- canary: fail if any real credential would be archived ---
CANARY_SECRET='CANARY__7f3a91e2__DO_NOT_COMMIT'

# --- staging directory ---
STAGING="$STAGING_ROOT/.archive-staging-$$"
rm -rf "$STAGING"
mkdir -p "$STAGING/src"
mkdir -p "$STAGING/scripts"
mkdir -p "$STAGING/migrations"
mkdir -p "$STAGING/tests"
mkdir -p "$STAGING/docs"
mkdir -p "$STAGING/public"
mkdir -p "$STAGING"

# Copy source files (only real project files — not hidden meta, not logs)
copy_if() {
  local pattern="$1"
  for f in $pattern; do
    [ -f "$f" ] || continue
    cp --parents "$f" "$STAGING/"
  done
}

copy_if "*.md"
copy_if "package.json"
copy_if "package-lock.json"
copy_if "tsconfig.json"
copy_if "next.config.ts"
copy_if "vitest.config.ts"
copy_if "vitest.integration.config.ts"
copy_if "eslint.config.mjs"
copy_if "next-env.d.ts"

copy_if "src/**/*.ts"
copy_if "src/**/*.tsx"
copy_if "src/**/*.css"
copy_if "src/**/*.json"

copy_if "scripts/*.sh"
copy_if "scripts/*.mjs"

copy_if "migrations/*.sql"

copy_if "tests/**/*.ts"
copy_if "tests/**/*.tsx"

copy_if "docs/**/*.md"
copy_if "docs/**/*.mdx"

copy_if "public/**/*"

# Root env.example only if validated (already done above)
if [ -f .env.example ]; then
  cp .env.example "$STAGING/"
fi

# --- inject canary file so the canary test can detect leakage ---
# This file must NOT appear in the final archive. If it does, the canary
# test fails. We place it inside staging to prove the exclusion list works.
mkdir -p "$STAGING/.canary-leak"
printf '%s\n' "$CANARY_SECRET" > "$STAGING/.canary-leak/canary-secret.txt"

# --- exclusion filter for tar ---
# Exclude: .git, .freebuff, all .env*, node_modules, .next, caches, logs,
# build artifacts, backups, typescript info, vercel, DS_Store, editor dirs.
EXCLUDES=(
  --exclude='.git'
  --exclude='.git/*'
  --exclude='.freebuff'
  --exclude='.freebuff/*'
  --exclude='.env'
  --exclude='.env.local'
  --exclude='.env.development.local'
  --exclude='.env.test.local'
  --exclude='.env.production.local'
  --exclude='.env.*'
  --exclude='.env.*/*'
  --exclude='**/.env'
  --exclude='**/.env.local'
  --exclude='**/.env.development.local'
  --exclude='**/.env.test.local'
  --exclude='**/.env.production.local'
  --exclude='**/.env.*'
  --exclude='node_modules'
  --exclude='node_modules/*'
  --exclude='**/node_modules'
  --exclude='**/node_modules/*'
  --exclude='.next'
  --exclude='.next/*'
  --exclude='**/.next'
  --exclude='**/.next/*'
  --exclude='coverage'
  --exclude='coverage/*'
  --exclude='**/coverage'
  --exclude='**/coverage/*'
  --exclude='*.log'
  --exclude='**/*.log'
  --exclude='build*.log'
  --exclude='**/build*.log'
  --exclude='*.tsbuildinfo'
  --exclude='**/*.tsbuildinfo'
  --exclude='next-env.d.ts'
  --exclude='**/next-env.d.ts'
  --exclude='.vercel'
  --exclude='.vercel/*'
  --exclude='**/.vercel'
  --exclude='**/.vercel/*'
  --exclude='*.pem'
  --exclude='**/*.pem'
  --exclude='.DS_Store'
  --exclude='**/.DS_Store'
  --exclude='.vscode'
  --exclude='.vscode/*'
  --exclude='**/.vscode'
  --exclude='**/.vscode/*'
  --exclude='.idea'
  --exclude='.idea/*'
  --exclude='**/.idea'
  --exclude='**/.idea/*'
  --exclude='dist'
  --exclude='dist/*'
  --exclude='**/dist'
  --exclude='**/dist/*'
  --exclude='out'
  --exclude='out/*'
  --exclude='**/out'
  --exclude='**/out/*'
  --exclude='.turbo'
  --exclude='.turbo/*'
  --exclude='**/.turbo'
  --exclude='**/.turbo/*'
  --exclude='.cache'
  --exclude='.cache/*'
  --exclude='**/.cache'
  --exclude='**/.cache/*'
  --exclude='.yarn'
  --exclude='.yarn/*'
  --exclude='**/.yarn'
  --exclude='**/.yarn/*'
  --exclude='pnpm-lock.yaml'
  --exclude='**/pnpm-lock.yaml'
  --exclude='yarn.lock'
  --exclude='**/yarn.lock'
  --exclude='package.json.backup'
  --exclude='**/package.json.backup'
  --exclude='.canary-leak'
  --exclude='.canary-leak/*'
  --exclude='**/.canary-leak'
  --exclude='**/.canary-leak/*'
)

cd "$STAGING"

# Create a fresh uncompressed archive first (no append to compressed).
tar cf "$chdir/.archive-raw.tmp" \
  "${EXCLUDES[@]}" \
  .

# Compress once, atomically.
gzip -n -f "$chdir/.archive-raw.tmp"
mv "$chdir/.archive-raw.tmp.gz" "$OUT"
chmod 644 "$OUT"
cd "$chdir"

rm -rf "$STAGING"
rm -f "$chdir/.archive-raw.tmp" "$chdir/.archive-raw.tmp.gz"

echo "build-archive: wrote $OUT"
echo "build-archive: size=$(stat -c%s "$OUT" 2>/dev/null || stat -f%z "$OUT") bytes"

# Canary summary printed for the canary test to grep.
printf '\nCANARY_SECRET=%s\n' "$CANARY_SECRET"
